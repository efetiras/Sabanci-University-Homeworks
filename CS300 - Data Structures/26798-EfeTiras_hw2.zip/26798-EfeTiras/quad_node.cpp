#include "quad_node.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;


QuadTree::~QuadTree() //destructor
{
	make_empty();

}

QuadTree::QuadTree() //constructor
{
	root = NULL;
	upper_limit_x = 0;
	upper_limit_y = 0;
}

void QuadTree::setLimit(double x, double y) //sets the upper x and upper y limits
{
	upper_limit_x = x;
	upper_limit_y = y;

}

void QuadTree::print() //public print function calls the private print function
	{
		priv_print(root);
	}

void QuadTree::priv_print(quadNode * ptr) //takes pointer as argument
	{   
		if(root == NULL) //if the tree is empty
		{
			cout<<"The tree is empty!"<<endl;
		}
		else if(ptr!= NULL) 
		{
			cout<<ptr->name<<endl; //print the name and recursively call this function to print the names
			priv_print(ptr->SE);
			priv_print(ptr->SW);
			priv_print(ptr->NE);
			priv_print(ptr->NW);
		}
	}

int QuadTree::district_no(const double & x, const double & y, const double & rad,  quadNode *  ptr ) //calculates the district of the city with coordinates x and y
{
	if(ptr != NULL) //enters if the ptr is not null
	{
		if(ptr->x <x-rad) //if x - rad is larger than pointer's x value
		{
			if(ptr->y < y-rad) //enters if pointer's y is smaller than y- rad and returns 6
			{
				return 6;
			}

			else if( ptr->y > y +rad) //returns 1 if ptr y is larger than y+rad
			{
				return 1;

			}

			else if(ptr->y > y-rad && ptr->y < y+rad) //enters if ptr's y is in the middle
			{
				return 4;

			}


		}

		else if(ptr->x > x+rad) //enters if ptr's x is in the right side of the point x,y
		{
			if(ptr->y <y-rad )
			{
				return 8;
			}

			else if(ptr->y >y+rad)
			{
				return 3;

			}
			else if(ptr->y > y-rad && ptr->y < y+rad)
			{
				return 5;
			}

		}

		else if(pow(ptr->x - x,2) + pow(ptr->y -y,2) <= pow(rad,2) ) // enters if the node is in the circle of the x,y coordinates
		{
			return 13; //if it is returns 13
		}

		else if(pow(ptr->x - x,2) + pow(ptr->y -y,2) > pow(rad,2) ) //if not in the circle
		{
			if(ptr->y > y+rad)
			{
				return 2;
			}

			else if(ptr->y < y-rad)
			{
				return 7;
			}

			else if(ptr->y >y && ptr->x <x)
			{
				return 9;
			}
			else if(ptr->y >y && ptr->x >x)
			{
				return 10;
			}

			else if(ptr->y< y && ptr->x < x)
			{
				return 11;
			}

			else if(ptr->y< y && ptr->x > x)
			{
				return 12 ;
			}

		}

	}

}
void QuadTree::priv_insert(const string & cityName, const double & x, const double & y, quadNode * & ptr) //private insert function
{
	if(upper_limit_x < x || upper_limit_y < y || x<0 || y<0) //if the values dont fit in the table return
	{
		return;
	}
	

	if(ptr == NULL) //base case for recursive call which creates the new quad node
	{ 
		ptr = new quadNode(cityName,x,y);
		ptr->SE = NULL;
		ptr->SW = NULL;
		ptr->NE = NULL;
		ptr->NW = NULL;
	}

	else if(x>ptr->x && y>ptr->y) //if x and y are larger insert NE
	{
	priv_insert(cityName, x,y, ptr->NE);
	
	}

	else if(x<ptr->x && y<ptr->y) //if x and y is smaller insert SW
	{
	priv_insert(cityName,x,y, ptr->SW);
	}

	else if(x>ptr->x && y<ptr->y) //if x is larger and y is smaller insert SE
	{
	priv_insert(cityName,x,y, ptr->SE);
	}
	
	else if(x<ptr->x && y>ptr->y) //if x is smaller and y is larger insert NW
	{
	priv_insert(cityName,x,y, ptr->NW);
	}

	else if(x == ptr->x && y<ptr->y) //if x is equal and y is smaller insert SE
	{
	priv_insert(cityName,x,y, ptr->SE);
	}

	else if(x <ptr->x && y == ptr->y)
	{
	priv_insert(cityName,x,y, ptr->SW);
	}

	else if(x == ptr->x && y==ptr->y)
	{
	priv_insert(cityName, x,y, ptr->NE);
	
	}

	else if(x == ptr->x && y>ptr->y)
	{
		priv_insert(cityName, x,y, ptr->NE);
	}

	else if(x >ptr->x && y == ptr->y)
	{
		priv_insert(cityName, x,y, ptr->NE);
	}

}
void QuadTree::insert(const string &cityName,const double & x, const double & y) //public insert calls priv insert
{   
	priv_insert(cityName,x,y,root);
}

void QuadTree::make_empty() //public make empty calls priv make empty
{
	priv_make_empty(root);
}

void QuadTree::priv_make_empty(quadNode * & ptr)
{
	if(ptr != NULL)
	{
		priv_make_empty(ptr->SE);
		priv_make_empty(ptr->SW);
		priv_make_empty(ptr->NE);
		priv_make_empty(ptr->NW);
		delete ptr;


	}
}

vector <string> SearchCities;
void QuadTree::priv_search(const double & x,const double & y, const double & rad, quadNode * & ptr) //priv search function
{
	if(ptr != NULL)
	{   
		
		SearchCities.push_back(ptr->name); //add the element in the vector
		
		if(district_no(x,y,rad,ptr) ==1 ) //if the element is in the region 1 search SE
		{
			priv_search(x,y,rad,ptr->SE);
		}

		else if(district_no(x,y,rad,ptr) ==2) //if the element is in the region 2 search SE and SW
		{
			priv_search(x,y,rad,ptr->SE);
			priv_search(x,y,rad,ptr->SW);
		}
	
		else if(district_no(x,y,rad,ptr) ==3)
		{
			priv_search(x,y,rad,ptr->SW);
		}

		else if(district_no(x,y,rad,ptr) ==4)
		{
			priv_search(x,y,rad,ptr->SE);
			priv_search(x,y,rad,ptr->NE);
		}
		else if(district_no(x,y,rad,ptr) ==5)
		{
			priv_search(x,y,rad,ptr->SW);
			priv_search(x,y,rad,ptr->NW);
		}
		else if(district_no(x,y,rad,ptr) ==6)
		{
			priv_search(x,y,rad,ptr->NE);
		}
		else if(district_no(x,y,rad,ptr) ==7)
		{
			priv_search(x,y,rad,ptr->NE);
			priv_search(x,y,rad,ptr->NW);
		}
		else if(district_no(x,y,rad,ptr) ==8)
		{
			priv_search(x,y,rad,ptr->NW);
		}
		else if(district_no(x,y,rad,ptr) ==9)
		{
			priv_search(x,y,rad,ptr->SE);
			priv_search(x,y,rad,ptr->SW);
			priv_search(x,y,rad,ptr->NE);

		}
		else if(district_no(x,y,rad,ptr) ==10)
		{
			priv_search(x,y,rad,ptr->SE);
			priv_search(x,y,rad,ptr->SW);
			priv_search(x,y,rad,ptr->NW);
		}
		else if(district_no(x,y,rad,ptr) ==11)
		{
			priv_search(x,y,rad,ptr->SE);
			priv_search(x,y,rad,ptr->NE);
			priv_search(x,y,rad,ptr->NW);
		}
		else if(district_no(x,y,rad,ptr) ==12)
		{
			priv_search(x,y,rad,ptr->SW);
			priv_search(x,y,rad,ptr->NE);
			priv_search(x,y,rad,ptr->NW);
		}
		
		else if(district_no(x,y,rad,ptr) ==13) //if the element is in the region 13 search all
		{
			priv_search(x,y,rad,ptr->SE);
			priv_search(x,y,rad,ptr->SW);
			priv_search(x,y,rad,ptr->NE);
			priv_search(x,y,rad,ptr->NW);
		}
	
	
	
	
	
	
	
	
	}

	


}

vector<string> InCircle;

void QuadTree::priv_searchInCircle(const double & x,const double & y, const double & rad, quadNode * & ptr) //finds the cities which are in the circle of the centered node
{
	if(ptr!= NULL)
	{   
		
		
		if(pow(ptr->x - x,2) + pow(ptr->y -y,2) <= pow(rad,2) )
		{   
			
			InCircle.push_back(ptr->name);
			
		}

		priv_searchInCircle(x,y,rad,ptr->SE);
		priv_searchInCircle(x,y,rad,ptr->SW);
		priv_searchInCircle(x,y,rad,ptr->NE);
		priv_searchInCircle(x,y,rad,ptr->NW);
	}

	
}
void QuadTree::search(const double & x,const double & y, const double & rad) //prints the names of the cities found
{   priv_searchInCircle(x,y,rad,root);
	
	if(InCircle.size() == 0)
		{
			cout<< "<None>"<<endl;
			
		}
	for(int i = 0; i<InCircle.size();i++)
	{
		
		
		if(i != InCircle.size() -1 )
		{
			cout<<InCircle[i]<<", ";
		}

		else if(i == InCircle.size() -1)
		{
			cout<<InCircle[i]<<endl;
		}
		

	}

	InCircle.clear();
	priv_search(x, y , rad, root);
	for(int i = 0; i<SearchCities.size(); i++)
		{
			if(i != SearchCities.size()-1)
			{
				cout<<SearchCities[i]<<", "; 
			}

			else if( i == SearchCities.size()-1)
			{
				cout<<SearchCities[i]<<endl<<endl;
			}

		}

		SearchCities.clear();
}