


#include <iostream>
#include <string>
using namespace std;

struct quadNode{

	quadNode * NW;
	quadNode * NE;
	quadNode * SW;
	quadNode * SE;
	double x;
	double y;
	string name;

	

	quadNode(string city_name ,double coorx, double coory):
		 x(coorx),y(coory), name(city_name){}
};

class QuadTree{
public:
	
    QuadTree();
	~QuadTree();
	
	void print () ;
	void insert(const string & city_name, const double & x, const double & y);
	

	void setLimit(double x, double y);
	int districtCalc(double x, double y,double radius);
	void make_empty();

	int district_no(const double & x, const double & y, const double & radius,  quadNode *  ptr);
	void search(const double & x, const double & y, const double & rad);

	void search_print(quadNode * ptr);
private:
	void priv_print(quadNode * ptr) ;
	quadNode *root;
	double upper_limit_x;
	double upper_limit_y;

	void priv_insert(const string & city_name, const double & x, const double & y, quadNode * & quad_root);
	void priv_make_empty(quadNode * & ptr);
	void priv_search(const double & x, const double & y, const double & rad, quadNode * & ptr);
	void priv_searchInCircle(const double & x, const double & y, const double & rad, quadNode * & ptr);
	
};
