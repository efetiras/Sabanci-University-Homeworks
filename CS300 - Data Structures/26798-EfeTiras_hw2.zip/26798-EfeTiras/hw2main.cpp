#include<iostream>
#include<fstream>
#include<sstream>
#include <vector>
#include <stdlib.h>
#include <array>
#include "quad_node.h"

using namespace std;


int main()
{ 
	ifstream citiesInfo("cities.txt");
	ifstream queriesInfo("queries.txt");

	string line1;
	string cities1;
	
	QuadTree MyQuadTree; //Quadtree is constructed

	int counter = 0;
	int counter2 = 0;
	vector<string> settingLimit;
	vector<string> cit;

	while (getline (citiesInfo, line1)) //for each line
	{   
		istringstream ss (line1);
		string mystr;
		while(ss>>mystr) //for each word
		{
			if(counter == 0 )
			{
				settingLimit.push_back(mystr); //pushbacks the x upper limit
				counter +=1;
			}

			else if(counter == 1)
			{
				settingLimit.push_back(mystr); //pushbacks the upper y limit
				counter += 1;
				MyQuadTree.setLimit(stod(settingLimit[0]),stod(settingLimit[1]) ); //sets limit

			}

			else
			{
				if(counter2 != 3)
				{
					cit.push_back(mystr);
					counter2 +=1;
					if(counter2 == 3)
					{
					MyQuadTree.insert(cit[0],stod(cit[1]),stod(cit[2]) ) ; //insert each city with its coordinate
					counter2 = 0;
					cit.clear();

					}
				}

				

			}

		}
	}

	MyQuadTree.print();
	cout<<endl;
	 
	vector<double> queriesVec;

	while (getline (queriesInfo, line1))  //for each line
	{   

		istringstream ss (line1);
		string str1,str2,str3;

		getline(ss,str1,','); //get the word until the comma
		queriesVec.push_back(stod(str1)); //push back to the vector
		getline(ss,str2,',');
		queriesVec.push_back(stod(str2));
		getline(ss,str3,',');
		queriesVec.push_back(stod(str3));
	
	}
    
	for(int i=0; i < queriesVec.size();i+=3)
	{
		MyQuadTree.search(queriesVec[i],queriesVec[i+1],queriesVec[i+2] ); //search those cities which are in vector
	}


	return 0;

	
}
