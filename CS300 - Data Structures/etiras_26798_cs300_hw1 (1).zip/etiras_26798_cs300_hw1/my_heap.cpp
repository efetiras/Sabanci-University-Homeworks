#include "my_heap.h"
#include <iostream>
#include <string>
using namespace std;


My_heap::~My_heap() //destructor prints the memory leak and deletes the memory stored in heap
{
	cout<<"At destruction, the heap had a memory leak of "<<used_bytes << " bytes."<<endl;
	memory_block * ptr = heap_begin;
	while(ptr != NULL)
	{
		delete ptr;
		ptr = ptr->right;
	}

}

My_heap::My_heap() //constructor initializes the private data members
{
	heap_begin = NULL;
	blk = NULL;
	used_bytes = 0;
	
}

memory_block * My_heap::bump_allocate(int byte) //allocates a new memory block with size byte
{
	

	if(heap_begin == NULL && blk == NULL) //if the heap is empty enters here and creates new memory block and assigns heap_begin pointer to this memory block
	{   
		heap_begin = new memory_block;
		heap_begin->starting_address = 0;
		
	    heap_begin->size = byte;
		heap_begin->used = true;
		
		blk = heap_begin;
		heap_begin->left = NULL;
		heap_begin->right = NULL;
		used_bytes += byte;
		return heap_begin;
	}

	else if(heap_begin != NULL) //if heap has at least one memory block enters here and creates new memory block and assigns the pointer left and right according to it
	{   
		memory_block * temp = new memory_block;
	   
		
		blk->right = temp; //temp is the last element
		
        temp->left = blk;
		
		int prevNodeEnd = blk->starting_address;
		temp->starting_address = prevNodeEnd + blk->size;
		temp->right = NULL;
		
		temp->size = byte;
	    temp->used = true;
		blk = temp; //now blk is assigned to be the last element
		used_bytes += byte; //increment the used bytes
		 
		return blk;

	}

	
}


void My_heap::deallocate( memory_block * to_delete) //in this member function it deallocates the memory block which is pointed by to_delete pointer and if this memory block has neighbooring free blocks merges them together to create one large free block
{
	
	
	if(heap_begin != NULL && blk!= NULL && heap_begin == blk) //if there is just one element
	{
		to_delete->used = false;
		used_bytes -= heap_begin->size;
	}

	else if(to_delete->left != NULL && to_delete->right != NULL && to_delete->left->used == false &&  to_delete->right->used == true) //if the left neighboor is free merge with it
	{  
		memory_block * freeLeftNode = to_delete->left; //free left node will become a large free block with merging with the memory block to be deleted
		freeLeftNode->size = freeLeftNode->size + to_delete->size;
		
		freeLeftNode->right = freeLeftNode->right->right; //free left node's right pointer now points to the to_delete's right memory block
		freeLeftNode->right->left = freeLeftNode;
		freeLeftNode->used = false;
		if(freeLeftNode->right == NULL) //if free left node becomes the last element with this merge its last pointer should be null and blk should point here
		{
			blk = freeLeftNode;
		}

		
		used_bytes -= to_delete->size;
	}

	else if(to_delete->right != NULL && to_delete->left!= NULL && to_delete->right->used == false &&  to_delete->left->used == true) //enters if the right neighboor is free and merge with it 
	{
		memory_block * freeRightNode = to_delete->right;
		to_delete->size = freeRightNode->size + to_delete->size;
		
		to_delete->right = to_delete->right->right;
		to_delete->used = false;
		if(to_delete->right == NULL)
		{
			blk = to_delete;
		}

		used_bytes -= to_delete->size;
	}

	else if(to_delete->left!= NULL && to_delete->right != NULL && to_delete->left->used == false &&  to_delete->right->used == false) //enters if the right and left neighboors are free and merge them together
	{
		memory_block * freeLeftBlock = to_delete->left;
		freeLeftBlock->size += to_delete->size + to_delete->right->size;
		freeLeftBlock->right = to_delete->right->right;
		
		freeLeftBlock->used = false;
		if(freeLeftBlock->right == NULL)
		{
			blk = freeLeftBlock;
		}
		else{
		freeLeftBlock->right->left = freeLeftBlock;
		}
		used_bytes -= to_delete->size;
	}

	else if(to_delete->left == NULL && to_delete->right!= NULL && to_delete->right->used == false) //enters if we want to deallocate the first element and its right neighboor is free
	{
		memory_block * temp = to_delete;
		temp->size += to_delete->right->size;
		temp->right = to_delete->right->right;
		temp->used = false;
		if(temp->right == NULL)
		{blk = temp;
		}
		else{
		temp->right->left = temp;
		}
		used_bytes -= to_delete->size;
	}

	else if(to_delete->right == NULL && to_delete->left!= NULL && to_delete->left->used == false) //enters if we want to deallocate the last element and its left element is free
	{
		memory_block * temp = to_delete->left;
		temp->size += to_delete->size;
		temp->right = to_delete->right;
		temp->used = false;
		if(temp->right == NULL)
		{blk = temp;
		}
		else{
		temp->right->left = temp;
		}
		used_bytes -= to_delete->size;
	}

	else{
		to_delete->used = false;
		used_bytes-= to_delete->size;
	}
}

memory_block * My_heap::first_fit_allocate(int bytes) //enters the first memory block which is free and equal or larger than the number bytes
{   
	if(bytes >512) //if bytes are larger than 512 return nullptr
	{
		return NULL;
	}
	memory_block * temp = heap_begin; //temp points to the first element
	if(heap_begin == NULL) //if the heap is empty create new memory block with size bytes 
	{   temp = new memory_block;
		temp->size = bytes;
		temp->left = NULL;
		temp->right = NULL;
		temp->starting_address = 0x0;
		heap_begin = temp;
		blk = temp;
		return heap_begin;
	}
	else{ // if the list is not empty
	while(temp != NULL) //until the end of the heap
	{
		if(temp->used == false && temp->size >= bytes) //if the temp is free and its size is enough to store bytes enters
		{
			temp->used = true;
			used_bytes += temp->size;
			return temp; //returns temp
		}

		temp = temp->right;
	}

	if(used_bytes+ bytes <= 512) //if no free memory block is found to fit byte size the program enters here 
	{
	temp = new memory_block; //new memory block is pointed by temp and added to the end of the list
	temp->size = bytes;
	temp->used = true;
	temp->right = NULL;
	temp->left = blk;
	temp->starting_address = blk->starting_address + blk->size;
	blk->right = temp;
	blk = temp;
	used_bytes += bytes;
	
	return temp;
	}
	else{ //if there is no enough memory return nullptr
		return NULL;
	}

	}
}

memory_block* My_heap::best_fit_allocate(int num_bytes) //finds the memory block which will minimize the wasted memory for num bytes if there is no free block addes new block to the end of the heap
{
	if(num_bytes >512)
	{
		return NULL;
	}
	memory_block * temp = heap_begin;
	if(heap_begin == NULL) //if the heap is empty
	{   temp = new memory_block;
		temp->size = num_bytes;
		temp->left = NULL;
		temp->right = NULL;
		temp->starting_address = 0x0;
		heap_begin = temp;
		blk = temp;
		used_bytes+= num_bytes;
		return heap_begin;

	}

	else
	{
		int max = 512; //created max variable to find the minimum wasted memory for a memory block
		memory_block * Valid = NULL;
		
		while(temp != NULL)
		{ 
			if(temp->used == false && temp->size >= num_bytes && (temp->size - num_bytes<= max) ) //tries to find the minimized wasted memory block
			{   
				max = temp->size - num_bytes; //updates max
				Valid = temp; //Valid pointer points to the temp
				
			}
            
			temp = temp->right;
			
		}

		if(Valid == NULL && num_bytes + used_bytes <= 512) //enters if there is no memory block found that fits our expectations
		{Valid = bump_allocate(num_bytes);
		Valid->used = true;
		}

		else if(Valid == NULL && num_bytes + used_bytes > 512)
		{return NULL;
		}

		else{
		Valid->used = true;
		used_bytes += Valid->size;
		}
		return Valid;
		

	}

	
}

memory_block * My_heap::first_fit_split_allocate(int num_bytes)
{
	if(num_bytes >512-used_bytes)
	{
		return NULL;
	}
	memory_block * temp = heap_begin;
	if(heap_begin == NULL)
	{   temp = new memory_block;
		temp->size = num_bytes;
		temp->left = NULL;
		temp->right = NULL;
		temp->starting_address = 0x0;
		heap_begin = temp;
		blk = temp;
		return heap_begin;
	}
	else{
	while(temp != NULL)
	{
		if(temp->used == false && temp->size >= num_bytes)
		{   if(temp->size == num_bytes)
			{
			temp->used = true;
			used_bytes += num_bytes;
			return temp;
		    }

			else if(temp->size > num_bytes)
			{memory_block * FromSplit = new memory_block;
			 int extraSize = temp->size- num_bytes;
			 temp->size = num_bytes;
			 FromSplit->right = temp->right;
			 FromSplit->right->left = FromSplit;
			 temp->right = FromSplit;
			 FromSplit->left = temp;
			 FromSplit->used = false;
			 FromSplit->starting_address = temp->starting_address + temp->size;
			 FromSplit->size = extraSize;
			 temp->used = true;
			 used_bytes+= num_bytes;
			 return temp;
			}
		}
		else{
		temp = temp->right;
		}
	}

	if(temp == NULL)
	{temp = new memory_block;
	temp->left = blk;
	temp->right = NULL;
	blk->right = temp;
	temp->size = num_bytes;
	temp->used = true;
	temp->starting_address = blk->starting_address + blk->size;
	used_bytes += temp->size;
	blk = temp;
	return blk;

	}

	

	}
}

float My_heap::get_fragmentation() //calculates the fragmentation
{
	int free_memory = 512-used_bytes; //free memory is the memory that we dont use
	int biggest_free_block = 512; //initialize biggest free block as 512
	int min = 0;
	memory_block * ptr = heap_begin;
	
	while(ptr != NULL)
	{
		biggest_free_block -= ptr->size; //decrement biggest free block with every memory block size
		ptr = ptr->right;
		
	}

	float freeFloat = (float) free_memory;
	float biggestBlockFloat = (float) biggest_free_block;
	float fragmentation = (freeFloat - biggestBlockFloat)/freeFloat * 100 ;
	return fragmentation ;

}

void My_heap::print_heap() //prints the heap accordingly
{
	cout<<"Maximum capacity of heap: 512B"<<endl;
	cout<<"Currently used memory (B): "<< used_bytes<<endl;

	int numberOfBlock=0;
	int numberOfUsed=0;
	int numberOfFree=0;
	memory_block * ptr = heap_begin;
	while(ptr != NULL)
	{
		if(ptr->used == false)
		{
			numberOfBlock +=1;
			numberOfFree +=1;
		}

		else if(ptr->used == true)
		{
			numberOfBlock +=1;
			numberOfUsed +=1;
		}

		ptr = ptr->right;

	}

	cout<<"Total memory blocks: "<<numberOfBlock<<endl;
	cout<<"Total used memory blocks: "<<numberOfUsed<<endl;
	cout<<"Total free memory blocks: "<<numberOfFree<<endl;
	cout<<"Fragmentation: "<< get_fragmentation()<<"%"<<endl;
	int starting = 0;
	
	memory_block * Check = heap_begin;
	while(Check != NULL)
	{   
		cout<<"Block " << starting<< "\t\tUsed: ";
		starting +=1;
		
		if(Check->used == true)
		{cout<<"True\tSize (B): ";
		}
		else
		{
			cout<<"False\tSize (B): ";
		}
		
		cout<< Check->size <<"\tStarting Address: "<<"0x"<< hex<<Check->starting_address <<"\n"; //prints the starting address in hexadecimal format
		cout<<dec;

		Check = Check->right;
	}



}
