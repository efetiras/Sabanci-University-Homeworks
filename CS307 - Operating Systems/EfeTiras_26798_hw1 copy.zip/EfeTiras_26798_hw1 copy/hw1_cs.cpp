#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int M[2][50]= {0};
int remaining = 100;
int turn = 0;

void *Thread1( void *) //Function for agency 1
{
while(1)
{ 
  
  int rand1 = rand() % 100; //rand1 is between 0 and 99
  if( (rand1<50 && M[0][rand1] == 0) || (rand1>= 50 && M[1][rand1-50]== 0) ) //enters if the seat number from rand1 is empty
  {
  while(turn != 0) {} //Busy waiting until turn is 0
  cout<<"Agency 1 Entered Critical Region"<<endl; 
 
  
  if(rand1<50 && M[0][rand1]== 0)  //enters if the seat to be booked is in the first row of the matrix
  {
    M[0][rand1] = 1; //books it as 1
    cout<<"Seat Number "<<rand1<<" is reserved by Agency 1"<<endl;
    remaining -=1; //decrements remaining
    
  }

  else if(rand1>=50 && M[1][rand1-50] == 0) //enters if the seat to be booked is in the second row
  {
    M[1][rand1-50] = 1; //books it as 1
    cout<<"Seat Number "<<rand1<<" is reserved by Agency 1"<<endl;
    remaining -=1; //decrements remaining
    

    
  }
  cout<<"Agency 1 Exit Critical Region"<<endl<<endl;
 
  turn = 1; 
  if(remaining == 0) //if there is no seat left exit the loop
  {break;
  }
  
  }
}

}
void *Thread2( void *) //same as agency 2
{
while(1)
{ 
 
  int rand2 = rand() % 100;
  if( (rand2<50 && M[0][rand2]== 0) || (rand2>=50 && M[1][rand2-50]==0) )
  {
  while(turn != 1) {}
  cout<<"Agency 2 Entered Critical Region"<<endl;
  
   
  if(rand2<50 && M[0][rand2] == 0)
  {
    M[0][rand2] = 2;
    cout<<"Seat Number "<<rand2<<" is reserved by Agency 2"<<endl;
    remaining -=1;
   
  }

  else if(rand2>=50 && M[1][rand2-50] == 0)
  {
    M[1][rand2-50] = 2;
    cout<<"Seat Number "<<rand2<<" is reserved by Agency 2"<<endl;
    remaining -=1;
    
  }
  cout<<"Agency 2 Exit Critical Region"<<endl<<endl;

  turn = 0;
  if(remaining == 0)
  {break;
  }
  
  }
}
}

int main()
{
   

	
 


    pthread_t TravelAgency1;
    pthread_t TravelAgency2;

     pthread_create(&TravelAgency1, NULL, Thread1, NULL); //two threads are created
     pthread_create(&TravelAgency2, NULL, Thread2, NULL);
     pthread_join(TravelAgency1,NULL);
     pthread_join(TravelAgency2,NULL);
    
    cout<<"No Seats Left"<<endl;
    
    for(int i=0;i<2;i++) //seats are printed in for loop
    {
     for(int j=0;j<50;j++)
     {
      if(i == 1 && j== 0)
      {cout<<endl;
      }
      cout<<M[i][j];

      
     }
    }
    return 0;


}
