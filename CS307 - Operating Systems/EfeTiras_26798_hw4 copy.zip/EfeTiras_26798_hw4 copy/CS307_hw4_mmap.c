#include <stdio.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{ int count = 0;
  int file_d = open("loremipsum.txt", O_RDWR);
  struct stat s;
  size_t size;
  int status = fstat(file_d, &s);
  size = s.st_size;

  char *ptr = mmap(0,size,PROT_READ|PROT_WRITE,MAP_SHARED,file_d,0);

  close(file_d);

  int i = 0;
  for( ; i < size;i++)
  {
    if(ptr[i] == 'a')
    {
        count = count + 1;

    }

  }

  printf("The file loremipsum has %d character 'a' ",count);


  status = munmap(ptr,size);
  return 0;

}
